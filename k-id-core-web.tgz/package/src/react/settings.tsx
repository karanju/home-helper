import { useEffect, useState } from 'react'

import type { KidErrorCode } from '../client'
import type { Permission, PermissionName } from '../core/types'
import { useEl, useKidStrings } from './context'
import { useKidPermissionSettings } from './hooks'
import { format } from './strings'

function usePermissionName(name: string): string {
  return useKidStrings().permissions[name]?.name ?? name
}

function PlayerRow({ permission }: { permission: Permission }) {
  const t = useKidStrings().settings
  const el = useEl()
  const { change } = useKidPermissionSettings()
  const [busy, setBusy] = useState(false)
  const [failed, setFailed] = useState(false)
  const name = format(t.enabledLabel, { permission: usePermissionName(permission.name) })

  // The checkbox stays bound to permission.enabled, so a failed change leaves the prior state in place.
  async function toggle(enabled: boolean) {
    setBusy(true)
    setFailed(false)
    try {
      const res = await change(permission.name, enabled)
      if (!res.ok) setFailed(true)
    } catch {
      setFailed(true)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div {...el('row')}>
      <span {...el('label')}>{name}</span>
      <span {...el('controlColumn')}>
        <label {...el('muted')}>
          <input
            type="checkbox"
            aria-label={name}
            checked={permission.enabled}
            disabled={busy}
            onChange={(e) => void toggle(e.target.checked)}
          />{' '}
          {permission.enabled ? t.on : t.off}
        </label>
        {failed ? (
          <span role="alert" {...el('danger')}>
            {t.error}
          </span>
        ) : null}
      </span>
    </div>
  )
}

function GuardianRow({
  permission,
  added,
  disabled,
  onToggle,
}: {
  permission: Permission
  added: boolean
  disabled: boolean
  onToggle: () => void
}) {
  const t = useKidStrings().settings
  const el = useEl()
  const name = format(t.enabledLabel, { permission: usePermissionName(permission.name) })
  return (
    <div {...el('row')}>
      <span {...el('label')}>{name}</span>
      {permission.enabled ? (
        <span {...el('muted')}>{t.granted}</span>
      ) : (
        <button
          {...el('pill', added ? 'pillAdded' : 'pillAsk')}
          type="button"
          aria-label={`${added ? t.added : t.ask} ${name}`}
          disabled={disabled}
          onClick={onToggle}
        >
          {added ? t.added : t.ask}
        </button>
      )}
    </div>
  )
}

/** Tier 2: the composable permission list. Player-managed permissions get an on/off control; guardian-managed
 * are staged with a tap and asked for in one request; prohibited are hidden. Place it inside <KidSettingsProvider>. */
export function KidPermissionSettings() {
  const strings = useKidStrings()
  const t = strings.settings
  const el = useEl()
  const { permissions, isLoaded, error, hasApproverEmail, upgrade, challenge } = useKidPermissionSettings()
  const [staged, setStaged] = useState<PermissionName[]>([])
  const [approverEmail, setApproverEmail] = useState('')
  const [failedCode, setFailedCode] = useState<KidErrorCode | undefined>()

  // Seed the editable set from a failed batch so a retry edits and submits the same list, never a subset.
  useEffect(() => {
    if (challenge.status === 'error') setStaged((s) => (s.length > 0 ? s : challenge.permissions))
  }, [challenge.status, challenge.permissions])

  if (error && !isLoaded)
    return (
      <p role="alert" {...el('danger')}>
        {t.error}
      </p>
    )
  if (!isLoaded) return null

  const inFlight = challenge.status === 'sending' || challenge.status === 'pending'
  const isAdded = (name: PermissionName) => (inFlight ? challenge.permissions.includes(name) : staged.includes(name))
  const toggle = (name: PermissionName) =>
    setStaged((s) => (s.includes(name) ? s.filter((n) => n !== name) : [...s, name]))

  const needsEmail = !hasApproverEmail && !inFlight

  async function ask(e: React.FormEvent) {
    e.preventDefault()
    if (staged.length === 0) return
    const names = staged
    setStaged([])
    const res = await upgrade(names, hasApproverEmail ? undefined : approverEmail)
    setFailedCode(res.ok ? undefined : res.code)
  }

  const ctaLabel = challenge.status === 'sending' ? t.asking : challenge.status === 'pending' ? t.waiting : t.askGrownup

  return (
    <>
      {permissions
        .filter((p) => p.managedBy !== 'PROHIBITED')
        .map((p) =>
          p.managedBy === 'GUARDIAN' ? (
            <GuardianRow
              key={p.name}
              permission={p}
              added={isAdded(p.name)}
              disabled={inFlight}
              onToggle={() => toggle(p.name)}
            />
          ) : (
            <PlayerRow key={p.name} permission={p} />
          ),
        )}
      {staged.length > 0 || inFlight ? (
        <form {...el('askForm')} onSubmit={(e) => void ask(e)}>
          {needsEmail ? (
            <>
              <label {...el('label')} htmlFor="kid-settings-approver-email">
                {strings.askAnAdult.title}
              </label>
              <p {...el('muted')}>{strings.askAnAdult.description}</p>
              <input
                {...el('input')}
                id="kid-settings-approver-email"
                type="email"
                autoComplete="email"
                placeholder={strings.askAnAdult.emailPlaceholder}
                value={approverEmail}
                onChange={(e) => setApproverEmail(e.target.value)}
                required
              />
            </>
          ) : null}
          <button {...el('button')} type="submit" disabled={inFlight || (needsEmail && !approverEmail)}>
            {ctaLabel}
          </button>
        </form>
      ) : null}
      {challenge.status === 'error' ? (
        <p role="alert" {...el('danger')}>
          {hasApproverEmail
            ? t.error
            : failedCode === 'invalid_request'
              ? strings.askAnAdult.invalidEmail
              : strings.askAnAdult.error}
        </p>
      ) : null}
    </>
  )
}

/** Tier 1: the prebuilt settings block. A titled surface wrapping <KidPermissionSettings>. */
export function KidSettings() {
  const t = useKidStrings().settings
  const el = useEl()
  return (
    <section {...el('card', 'settings')}>
      <h2 {...el('title')}>{t.title}</h2>
      <KidPermissionSettings />
    </section>
  )
}
