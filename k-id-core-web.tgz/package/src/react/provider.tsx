import { type ReactNode, useEffect, useMemo, useRef, useState, useSyncExternalStore } from 'react'

import { createClient, type Client, type DeclareInput } from '../client'
import {
  createAgeGateController,
  createAskWatcher,
  createSessionStore,
  type AgeGateController,
  type AskWatcher,
  resumableChallengeId,
  type SessionStore,
} from '../core'
import type { AgeSignal, Appearance } from '../core/types'
import { type DeclarationStatus, KidCoreContext, KidSessionContext, useKidCoreContext } from './context'
import { declareRetryDelayMs, isLiveKey, isRetryableDeclareError, MAX_DECLARE_ATTEMPTS } from './declare-retry'
import type { JurisdictionCode } from '../catalog/jurisdictions'
import { type KidLocalization, mergeStrings, textDirection } from './strings'
import { injectStyles } from './styles'
import { appearanceToCssVars } from './theme'

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms))

/** The integration config, read once at mount; later prop changes are ignored. Applied to the product's TEST config only. */
export type KidDeclare = DeclareInput

export type KidCoreProviderProps = {
  publishableKey: string
  /** The `/fapi` endpoint. Defaults to the same-origin `/fapi/v1`. */
  baseUrl?: string
  appearance?: Appearance
  /** Partial widget-copy overrides (wording or a locale's strings), merged over the English defaults. */
  localization?: KidLocalization
  declare?: KidDeclare
  children: ReactNode
}

export function KidCoreProvider({
  publishableKey,
  baseUrl,
  appearance,
  localization,
  declare,
  children,
}: KidCoreProviderProps) {
  const strings = useMemo(() => mergeStrings(localization), [localization])
  const locale = localization?.locale
  const dir = textDirection(locale)

  useEffect(() => injectStyles(), [])

  const clientRef = useRef<Client | null>(null)
  if (!clientRef.current) clientRef.current = createClient({ publishableKey, baseUrl })
  const client = clientRef.current
  const sessionsRef = useRef<SessionStore | null>(null)
  if (!sessionsRef.current) sessionsRef.current = createSessionStore()
  const sessions = sessionsRef.current
  const asksRef = useRef<AskWatcher | null>(null)
  if (!asksRef.current) asksRef.current = createAskWatcher({ client, sessions })
  const asks = asksRef.current

  useEffect(() => {
    asks.start()
    return () => asks.stop()
  }, [asks])

  // The flow reads the TEST config declare writes, so it is gated on this readiness.
  // A live key's declare is a server no-op, so live page loads skip the round-trip.
  const declared = isLiveKey(publishableKey) ? undefined : declare
  const [declarationStatus, setDeclarationStatus] = useState<DeclarationStatus>(declared ? 'pending' : 'ready')

  const started = useRef(false)
  useEffect(() => {
    if (!declared || started.current) return
    started.current = true

    // Declare is idempotent server-side, so retrying a transient failure is safe (it noops if the config
    // already landed). This retries on failure; it is not a readiness poll loop.
    void (async () => {
      for (let attempt = 1; ; attempt++) {
        try {
          await client.declare(declared)
          setDeclarationStatus('ready')
          return
        } catch (e: unknown) {
          if (attempt >= MAX_DECLARE_ATTEMPTS || !isRetryableDeclareError(e)) {
            console.error('[k-ID] declare failed', e)
            setDeclarationStatus('error')
            return
          }
          await sleep(declareRetryDelayMs(attempt))
        }
      }
    })()
  }, [client, declared])

  const value = useMemo(
    () => ({ client, sessions, asks, appearance, strings, locale, dir, declarationStatus }),
    [client, sessions, asks, appearance, strings, locale, dir, declarationStatus],
  )

  return (
    <KidCoreContext.Provider value={value}>
      <div style={{ display: 'contents', ...appearanceToCssVars(appearance) }}>{children}</div>
    </KidCoreContext.Provider>
  )
}

export type KidSessionProviderProps = {
  /**
   * ISO 3166-1 alpha-2 country or ISO 3166-2 subdivision code, or `"auto"` to resolve it from the client IP
   * server-side (falls back to the in-widget picker when it can't be resolved). Omit to show the picker.
   */
  jurisdiction?: 'auto' | JurisdictionCode | (string & {})
  age?: AgeSignal
  email?: string
  /** Resume an in-flight flow; persist these from `onChallenge`/`onSession` and pass them back. */
  challengeId?: string
  sessionId?: string
  onChallenge?: (challengeId: string) => void
  onSession?: (sessionId: string) => void
  /**
   * Fires once the age check has a result, pass or pending, with a one-time token for your backend. Not fired on resume
   * or when the player is prohibited.
   */
  onClaim?: (claimToken: string) => void
  children: ReactNode
}

export function KidSessionProvider({
  jurisdiction,
  age,
  email,
  challengeId,
  sessionId,
  onChallenge,
  onSession,
  onClaim,
  children,
}: KidSessionProviderProps) {
  const { client, sessions, declarationStatus } = useKidCoreContext()
  const controllerRef = useRef<AgeGateController | null>(null)
  if (!controllerRef.current) {
    controllerRef.current = createAgeGateController({
      client,
      sessions,
      initial: { jurisdiction, age, email, challengeId, sessionId },
    })
  }
  const controller = controllerRef.current

  // The flow reads the TEST config declare writes, so it holds its requests until declare lands.
  useEffect(() => {
    if (declarationStatus === 'error') {
      controller.declarationFailed()
      return
    }
    if (declarationStatus !== 'ready') return
    controller.start()
    return () => controller.destroy()
  }, [controller, declarationStatus])

  // The declarative inputs can change after mount; resume ids (challengeId/sessionId) are fixed at creation.
  const ageKey = JSON.stringify(age ?? null)
  useEffect(() => {
    controller.configure({ jurisdiction, age, email })
    // age is compared by value via ageKey; depending on the object identity would loop every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [controller, jurisdiction, ageKey, email])

  const outChallengeId = useSyncExternalStore(
    controller.subscribe,
    () => resumableChallengeId(controller.getState()),
    () => resumableChallengeId(controller.getState()),
  )
  const outSessionId = useSyncExternalStore(
    controller.subscribe,
    () => controller.getState().sessionId,
    () => controller.getState().sessionId,
  )

  const firedChallenge = useRef<string | null>(null)
  useEffect(() => {
    if (outChallengeId && outChallengeId !== firedChallenge.current) {
      firedChallenge.current = outChallengeId
      onChallenge?.(outChallengeId)
    }
  }, [outChallengeId, onChallenge])

  const firedSession = useRef<string | null>(null)
  useEffect(() => {
    if (outSessionId && outSessionId !== firedSession.current) {
      firedSession.current = outSessionId
      onSession?.(outSessionId)
    }
  }, [outSessionId, onSession])

  const outClaimToken = useSyncExternalStore(
    controller.subscribe,
    () => controller.getState().claimToken,
    () => controller.getState().claimToken,
  )

  const firedClaim = useRef<string | null>(null)
  useEffect(() => {
    if (outClaimToken && outClaimToken !== firedClaim.current) {
      firedClaim.current = outClaimToken
      onClaim?.(outClaimToken)
    }
  }, [outClaimToken, onClaim])

  const value = useMemo(() => ({ controller }), [controller])
  return <KidSessionContext.Provider value={value}>{children}</KidSessionContext.Provider>
}
