import { scriptBotCheck, type BotCheckHint, type BotCheckProvider } from './botCheck'
import type { components } from './fapi-schema'

type ClientToken = components['schemas']['ClientToken']

export interface DeviceKey {
  publicJwk: JsonWebKey
  /** Returns the raw 64-byte `r || s` signature JWS expects. */
  sign(data: Uint8Array): Promise<Uint8Array>
}

export interface DeviceKeyProvider {
  getKey(): Promise<DeviceKey>
}

export type FapiSend = (
  path: string,
  init: { method: string; headers: Record<string, string>; body?: unknown },
) => Promise<{
  ok: boolean
  status: number
  data: { error?: string } & Record<string, unknown>
}>

const encoder = new TextEncoder()

function base64url(bytes: Uint8Array): string {
  let binary = ''
  for (const b of bytes) binary += String.fromCharCode(b)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function randomId(): string {
  return base64url(crypto.getRandomValues(new Uint8Array(16)))
}

async function sha256(text: string): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(text)))
}

let sharedWebCryptoKey: Promise<DeviceKey> | null = null

export const webCryptoKeyProvider: DeviceKeyProvider = {
  getKey() {
    sharedWebCryptoKey ??= (async () => {
      const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign', 'verify'])
      const { kty, crv, x, y } = await crypto.subtle.exportKey('jwk', pair.publicKey)
      return {
        publicJwk: { kty, crv, x, y },
        async sign(data: Uint8Array) {
          return new Uint8Array(
            await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, pair.privateKey, data as BufferSource),
          )
        },
      }
    })().catch((err) => {
      sharedWebCryptoKey = null
      throw err
    })
    return sharedWebCryptoKey
  },
}

/** `url` must be absolute. */
export async function createDPoPProof(
  key: DeviceKey,
  method: string,
  url: string,
  extra: { nonce?: string; accessToken?: string } = {},
): Promise<string> {
  const target = new URL(url)
  const header = { typ: 'dpop+jwt', alg: 'ES256', jwk: key.publicJwk }
  const claims: Record<string, unknown> = {
    htm: method,
    htu: `${target.origin}${target.pathname}`,
    iat: Math.floor(Date.now() / 1000),
    jti: randomId(),
  }
  if (extra.nonce) claims.nonce = extra.nonce
  if (extra.accessToken) claims.ath = base64url(await sha256(extra.accessToken))
  const signingInput = `${base64url(encoder.encode(JSON.stringify(header)))}.${base64url(encoder.encode(JSON.stringify(claims)))}`
  return `${signingInput}.${base64url(await key.sign(encoder.encode(signingInput)))}`
}

/** A token is refreshed this long before it expires, so a call never races its expiry. */
const EXPIRY_MARGIN_MS = 60_000

/** So an outage of the mint endpoints doesn't add two requests to every call. */
const MINT_COOLDOWN_MS = 60_000

export class ClientTrust {
  private token: ClientToken | null = null
  private minting: Promise<ClientToken | null> | null = null
  private nextMintAt = 0

  constructor(
    private readonly send: FapiSend,
    private readonly resolveUrl: (path: string) => string,
    private readonly keys: DeviceKeyProvider = webCryptoKeyProvider,
    private readonly botCheck: BotCheckProvider = scriptBotCheck,
  ) {}

  async headers(method: string, path: string): Promise<Record<string, string>> {
    const token = await this.current()
    if (!token) return {}
    try {
      const key = await this.keys.getKey()
      const proof = await createDPoPProof(key, method, this.resolveUrl(path), { accessToken: token.clientToken })
      return { 'Kid-Client': token.clientToken, DPoP: proof }
    } catch {
      return {}
    }
  }

  invalidate(): void {
    this.token = null
  }

  private async current(): Promise<ClientToken | null> {
    if (this.token && Date.parse(this.token.expiresAt) - EXPIRY_MARGIN_MS > Date.now()) return this.token
    if (Date.now() < this.nextMintAt) return null
    this.minting ??= this.mint()
      .then((token) => {
        if (!token) this.nextMintAt = Date.now() + MINT_COOLDOWN_MS
        return token
      })
      .finally(() => {
        this.minting = null
      })
    this.token = await this.minting
    return this.token
  }

  private async mint(): Promise<ClientToken | null> {
    try {
      const key = await this.keys.getKey()
      const challenge = await this.send('/client/challenge', { method: 'POST', headers: {} })
      const nonce = challenge.ok ? challenge.data.nonce : undefined
      if (typeof nonce !== 'string') return null
      const body: components['schemas']['ClientAttestRequest'] = { platform: 'web' }
      const hint = challenge.data.botCheck as BotCheckHint | undefined
      if (hint) body.botCheckToken = await this.botCheck.token(hint)
      // The proof is signed last, so a slow bot check does not age it.
      const proof = await createDPoPProof(key, 'POST', this.resolveUrl('/client/attest'), { nonce })
      const attest = await this.send('/client/attest', { method: 'POST', headers: { DPoP: proof }, body })
      return attest.ok ? (attest.data as unknown as ClientToken) : null
    } catch {
      return null
    }
  }
}
