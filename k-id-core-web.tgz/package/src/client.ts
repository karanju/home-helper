import type { PermissionName } from './catalog/permissions'
import type { BotCheckProvider } from './botCheck'
import { ClientTrust, type DeviceKeyProvider } from './clientTrust'
import { declaredIconUrl } from './declareIcon'
import type { components } from './fapi-schema'
import { createSseParser } from './sse'

type Schemas = components['schemas']

export type Permission = Omit<Schemas['Permission'], 'name'> & { name: PermissionName }
export type Session = Omit<Schemas['Session'], 'permissions'> & { permissions: Permission[] }
export type Challenge = Schemas['Challenge']
export type ChallengeStatus = Omit<Schemas['ChallengeStatus'], 'permissions'> & { permissions?: PermissionName[] }
export type AgeResult = Omit<Schemas['CheckAgeGateResponse'], 'session'> & { session?: Session }
export type Requirements = Schemas['AgeGateRequirements']
export type InviteParentResult = Schemas['InviteParentResponse']
export type AgeVerification = Schemas['AgeVerification']

export type AgeSignal = { dateOfBirth: string } | { age: number }
export type PlatformAgeSignal = Schemas['PlatformAgeSignal']

/** What the app declares. `permissions` and `supportEmail` are always sent; leave another field out to keep what k-ID has, or send null to clear it. */
export type DeclareInput = {
  permissions: { name: PermissionName }[]
  privacyPolicyUrl?: string | null
  termsOfServiceUrl?: string | null
  /** A public https link, or any image the app can load (a bundled asset, a local path), which is sent inline. */
  iconUrl?: string | null
  /** Required. The address k-ID's emails give players and parents for help. */
  supportEmail: string
}

/** A read of the session, carrying the etag so a caller can make the next read conditional. */
export type SessionRead = { session: Session | null; etag: string | null; notModified: boolean }

/** Result of a player opt-in/opt-out change: the updated session, or a user-recoverable failure with a code. */
export type SessionChangeResult = { ok: true; session: Session } | { ok: false; code: KidErrorCode; error: string }

/** Result of a guardian upgrade request: the session plus any minted upgrade challenge to email and poll. */
export type SessionUpgradeResult = { session: Session; challenge: Challenge | null }

export type SessionVerifyAgeResult = {
  status: Schemas['VerifySessionAgeResponse']['status']
  challenge: Challenge | null
}

/** The closed set of error codes the SDK surfaces, grouped by what the developer does about it. Specifics
 * ride in `message` (dev-facing) or the coarse end-user `status:'error'`. */
export type KidErrorCode = 'invalid_request' | 'unauthorized' | 'not_found' | 'rate_limited' | 'unavailable'

// The API returns almost every error as HTTP 400, so map on the JSON `error` code, not the status.
const RAW_ERROR_TO_CODE: Record<string, KidErrorCode> = {
  NOT_FOUND: 'not_found',
  UNAUTHORIZED: 'unauthorized',
  TOO_MANY_REQUESTS: 'rate_limited',
  INVALID_INPUT: 'invalid_request',
  INVALID_EMAIL: 'invalid_request',
  AGE_CONFLICT: 'invalid_request',
  CLIENT_TOKEN_INVALID: 'unauthorized',
  FEATURE_DISABLED: 'unavailable',
  CANNOT_RESOLVE_JURISDICTION: 'unavailable',
  INTERNAL_ERROR: 'unavailable',
  UNKNOWN: 'unavailable',
}

export function toKidErrorCode(rawCode: string | undefined, status: number): KidErrorCode {
  if (rawCode && rawCode in RAW_ERROR_TO_CODE) return RAW_ERROR_TO_CODE[rawCode]
  if (status === 429) return 'rate_limited'
  if (status === 401 || status === 403) return 'unauthorized'
  if (status === 404) return 'not_found'
  if (status >= 400 && status < 500) return 'invalid_request'
  return 'unavailable'
}

/** Developer-facing default `KidError` messages, keyed by case. Fixed and scrubbed of server detail; a
 * developer showing an end-user message maps the closed `code` to their own copy. */
type KidErrorMessages = {
  invalidRequest: string
  invalidAgeSignal: string
  invalidJurisdiction: string
  ageConflict: string
  challengeIdRequired: string
  challengeResolved: string
  emailMismatch: string
  permissionNotChangeable: string
  unauthorizedKey: string
  unauthorizedOrigin: string
  sessionNotFound: string
  challengeNotFound: string
  rateLimited: string
  serverError: string
  featureDisabled: string
}

const DEFAULT_ERROR_MESSAGES: KidErrorMessages = {
  invalidRequest: 'The request was invalid.',
  invalidAgeSignal: 'Provide a valid date of birth or age.',
  invalidJurisdiction: 'Unknown or invalid jurisdiction code.',
  ageConflict: 'The platform age signal conflicts with the provided age.',
  challengeIdRequired: 'A challenge id is required.',
  challengeResolved: 'This challenge is already resolved; no email can be sent.',
  emailMismatch: "The email address doesn't match this challenge's approver, or is required.",
  permissionNotChangeable: "That permission can't be changed here.",
  unauthorizedKey: 'Invalid or unrecognized publishable key.',
  unauthorizedOrigin: "This origin isn't allowed for your publishable key.",
  sessionNotFound: 'Session not found.',
  challengeNotFound: 'Challenge not found.',
  rateLimited: 'Too many requests. Please wait and try again.',
  serverError: 'Something went wrong on our side. Please try again.',
  featureDisabled: "This feature isn't enabled for this product.",
}

const INVALID_INPUT_SUBCASES: { test: RegExp; key: keyof KidErrorMessages }[] = [
  { test: /invalid jurisdiction/i, key: 'invalidJurisdiction' },
  { test: /dateofbirth|date of birth/i, key: 'invalidAgeSignal' },
  { test: /challenge id must be provided/i, key: 'challengeIdRequired' },
  { test: /completed challenge/i, key: 'challengeResolved' },
]

type MessageKeys = { notFound?: keyof KidErrorMessages; invalid?: keyof KidErrorMessages }

function resolveErrorMessage(
  rawCode: string | undefined,
  rawMessage: string | undefined,
  status: number,
  keys: MessageKeys,
  msgs: KidErrorMessages,
): string {
  switch (rawCode) {
    case 'AGE_CONFLICT':
      return msgs.ageConflict
    case 'INVALID_EMAIL':
      return msgs.emailMismatch
    case 'FEATURE_DISABLED':
      return msgs.featureDisabled
    case 'TOO_MANY_REQUESTS':
      return msgs.rateLimited
    case 'UNAUTHORIZED':
      return status === 403 ? msgs.unauthorizedOrigin : msgs.unauthorizedKey
    case 'INTERNAL_ERROR':
      return msgs.serverError
    case 'NOT_FOUND':
      return msgs[keys.notFound ?? 'sessionNotFound']
  }
  if (status === 429) return msgs.rateLimited
  if (status === 401 || status === 403) return status === 403 ? msgs.unauthorizedOrigin : msgs.unauthorizedKey
  if (status >= 500 || status === 0) return msgs.serverError
  const subcase = rawMessage ? INVALID_INPUT_SUBCASES.find((s) => s.test.test(rawMessage)) : undefined
  return msgs[subcase?.key ?? keys.invalid ?? 'invalidRequest']
}

export type SendEmailResult = { ok: boolean; code?: KidErrorCode; error?: string }

/** How an opened challenge stream ended: the server closed it (with its reconnect hint, if any), or the connection
 * dropped. */
export type ChallengeStreamEnd = { closed: true; retryMs?: number } | { closed: false }

/** A non-2xx error from the k-ID API. `code` is one of the closed `KidErrorCode` set; `message` is safe to
 * display (never raw server text). `rawCode` is the underlying server code, kept for internal flow branches. */
export class KidError extends Error {
  constructor(
    readonly status: number,
    readonly code: KidErrorCode,
    message: string,
    readonly rawCode: string | undefined,
  ) {
    super(message)
    this.name = 'KidError'
  }
}

export interface ClientOptions {
  /** Sent as `Authorization: Bearer`. */
  publishableKey?: string
  baseUrl?: string
  /** Injected fetch (tests / SSR). Default: global `fetch`. */
  fetchImpl?: typeof fetch
  /** The device key a live key's calls are bound to. Default: a non-extractable WebCrypto key. */
  deviceKeys?: DeviceKeyProvider
  /** Solves the bot check k-ID asks a live key's mint for. Default: reCAPTCHA Enterprise, loaded into the page. */
  botCheck?: BotCheckProvider
}

export interface Client {
  /** Age-gate check. An absent jurisdiction is resolved server-side from the client IP. A platform age signal stands in
   * for an absent age. */
  ageGateCheck(
    age: AgeSignal | undefined,
    jurisdiction?: string,
    platformAgeSignal?: PlatformAgeSignal,
  ): Promise<AgeResult>
  /** Whether the server will use a platform age signal from this client. */
  platformAgeSignalTrusted(): Promise<boolean>
  getRequirements(jurisdiction?: string): Promise<Requirements>
  /** Get a player session by id. Pass a prior etag to let an unchanged session 304. */
  sessionGet(sessionId: string, etag?: string): Promise<SessionRead>
  challengeGetStatus(challengeId: string): Promise<ChallengeStatus>
  /** Stream the challenge's status, calling `onStatus` with each one, until the stream ends. Throws a `KidError` when
   * the stream can't be opened; `not_found` means streaming is unavailable, so poll instead. */
  challengeStream(
    challengeId: string,
    onStatus: (status: ChallengeStatus) => void,
    signal: AbortSignal,
  ): Promise<ChallengeStreamEnd>
  /** Send the consent request. Omit `email` to reach the challenge's existing approver (guardian upgrade on a
   * linked session). Re-callable to re-send to a still-pending challenge. */
  challengeSendEmail(challengeId: string, email?: string): Promise<SendEmailResult>
  /** Send a parent-invite challenge (VPL). Mirrors the wire; unused by the VPC flow. */
  challengeInviteParent(sessionId: string, parentEmail: string, playerName?: string): Promise<InviteParentResult>
  /** Enable or disable a player-managed permission (opt-in/opt-out). User-recoverable failures return a code. */
  sessionChange(sessionId: string, name: PermissionName, enabled: boolean): Promise<SessionChangeResult>
  /** Request a guardian upgrade for guardian-managed permissions; mints a challenge to email and poll. */
  sessionUpgrade(sessionId: string, permissionNames: PermissionName[]): Promise<SessionUpgradeResult>
  sessionVerifyAge(sessionId: string): Promise<SessionVerifyAgeResult>
  /** Declare the app's config (test mode only). Throws on a non-2xx. */
  declare(input: DeclareInput): Promise<void>
}

function bearer(key: string | undefined): Record<string, string> {
  return key ? { Authorization: `Bearer ${key}` } : {}
}

export function createClient(options: ClientOptions = {}): Client {
  const baseUrl = (options.baseUrl ?? '/fapi/v1').replace(/\/+$/, '')
  const doFetch = options.fetchImpl ?? fetch.bind(globalThis)

  function kidError(status: number, data: { error?: string; errorMessage?: string }, keys: MessageKeys = {}): KidError {
    return new KidError(
      status,
      toKidErrorCode(data.error, status),
      resolveErrorMessage(data.error, data.errorMessage, status, keys, DEFAULT_ERROR_MESSAGES),
      data.error,
    )
  }

  type Sent<T> = { ok: boolean; status: number; data: T; etag: string | null }

  // A transport failure (offline / DNS / CORS / abort) becomes a synthetic status-0 non-ok, mapped like any other.
  async function send<T>(
    path: string,
    init: { method: string; headers: Record<string, string>; body?: unknown },
  ): Promise<Sent<T>> {
    let r: Response
    try {
      r = await doFetch(`${baseUrl}${path}`, {
        method: init.method,
        headers: {
          ...(init.method === 'POST' ? { 'Content-Type': 'application/json' } : {}),
          ...bearer(options.publishableKey),
          ...init.headers,
        },
        ...(init.method === 'POST' ? { body: JSON.stringify(init.body ?? {}) } : {}),
      })
    } catch {
      return { ok: false, status: 0, data: {} as T, etag: null }
    }
    const data = (await r.json().catch(() => ({}))) as T
    return { ok: r.ok, status: r.status, data, etag: r.headers?.get?.('etag') ?? null }
  }

  // The proof must name the absolute URL, so a relative baseUrl is resolved against the page.
  const clientTrust =
    options.publishableKey && globalThis.crypto?.subtle
      ? new ClientTrust(
          (path, init) => send(path, init),
          (path) => new URL(`${baseUrl}${path}`, globalThis.location?.href).href,
          options.deviceKeys,
          options.botCheck,
        )
      : null

  async function trusted<T>(
    path: string,
    init: { method: string; headers?: Record<string, string>; body?: unknown },
  ): Promise<Sent<T>> {
    const attempt = async () =>
      send<T>(path, {
        method: init.method,
        body: init.body,
        headers: { ...(init.headers ?? {}), ...(clientTrust ? await clientTrust.headers(init.method, path) : {}) },
      })
    const first = await attempt()
    if (!clientTrust || (first.data as { error?: string })?.error !== 'CLIENT_TOKEN_INVALID') return first
    clientTrust.invalidate()
    return attempt()
  }

  async function post<T>(path: string, body: unknown): Promise<{ ok: boolean; status: number; data: T }> {
    return trusted<T>(path, { method: 'POST', body })
  }

  async function get<T>(path: string, headers: Record<string, string> = {}): Promise<Sent<T>> {
    return trusted<T>(path, { method: 'GET', headers })
  }

  return {
    async ageGateCheck(age, jurisdiction, platformAgeSignal) {
      const body: Schemas['CheckAgeGateRequest'] = {
        ...age,
        ...(jurisdiction ? { jurisdiction } : {}),
        ...(platformAgeSignal ? { platformAgeSignal } : {}),
      }
      const { ok, status, data } = await post<AgeResult & { error?: string; errorMessage?: string }>(
        '/age-gate/check',
        body,
      )
      if (!ok) throw kidError(status, data, { invalid: 'invalidAgeSignal' })
      return data
    },

    // The server trusts a platform age signal only from an iOS app.
    async platformAgeSignalTrusted() {
      return false
    },

    async getRequirements(jurisdiction) {
      const query = jurisdiction ? `?jurisdiction=${encodeURIComponent(jurisdiction)}` : ''
      const { ok, status, data } = await get<Requirements & { error?: string; errorMessage?: string }>(
        `/age-gate/get-requirements${query}`,
      )
      if (!ok) throw kidError(status, data, { invalid: 'invalidJurisdiction' })
      return data
    },

    async sessionGet(sessionId, etag) {
      const {
        ok,
        status,
        data,
        etag: responseEtag,
      } = await get<Session & { error?: string; errorMessage?: string }>(
        `/session/get?sessionId=${encodeURIComponent(sessionId)}`,
        etag ? { 'If-None-Match': etag } : {},
      )
      if (status === 304) return { session: null, etag: etag ?? null, notModified: true }
      if (!ok) {
        const err = kidError(status, data, { notFound: 'sessionNotFound' })
        // A stale/unknown session is a normal resume outcome, not a throw.
        if (err.code === 'not_found') return { session: null, etag: null, notModified: false }
        throw err
      }
      return { session: data, etag: data.etag ?? responseEtag, notModified: false }
    },

    async challengeGetStatus(challengeId) {
      const { ok, status, data } = await get<ChallengeStatus & { error?: string; errorMessage?: string }>(
        `/challenge/get-status?challengeId=${encodeURIComponent(challengeId)}`,
      )
      if (!ok) throw kidError(status, data, { notFound: 'challengeNotFound' })
      return data
    },

    async challengeStream(challengeId, onStatus, signal) {
      const path = `/challenge/stream?challengeId=${encodeURIComponent(challengeId)}`
      const open = async () =>
        doFetch(`${baseUrl}${path}`, {
          method: 'GET',
          headers: {
            Accept: 'text/event-stream',
            ...bearer(options.publishableKey),
            ...(clientTrust ? await clientTrust.headers('GET', path) : {}),
          },
          signal,
        })
      const refused = async (r: Response) =>
        kidError(r.status, (await r.json().catch(() => ({}))) as { error?: string; errorMessage?: string }, {
          notFound: 'challengeNotFound',
        })

      let r: Response
      try {
        r = await open()
        if (!r.ok) {
          const err = await refused(r)
          if (!clientTrust || err.rawCode !== 'CLIENT_TOKEN_INVALID') throw err
          clientTrust.invalidate()
          r = await open()
        }
      } catch (e) {
        if (e instanceof KidError) throw e
        throw kidError(0, {})
      }
      if (!r.ok) throw await refused(r)
      // A proxy that answers with something other than a stream can't stream to this client.
      if (!r.body || !r.headers.get('content-type')?.startsWith('text/event-stream')) throw kidError(0, {})

      const parser = createSseParser(({ event, data }) => {
        if (event !== 'status') return
        let status: ChallengeStatus
        try {
          status = JSON.parse(data) as ChallengeStatus
        } catch {
          return
        }
        onStatus(status)
      })
      const reader = r.body.getReader()
      const decoder = new TextDecoder()
      try {
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          parser.push(decoder.decode(value, { stream: true }))
        }
      } catch {
        return { closed: false }
      }
      parser.push(decoder.decode())
      return { closed: true, ...(parser.retryMs !== undefined ? { retryMs: parser.retryMs } : {}) }
    },

    async challengeSendEmail(challengeId, email) {
      const body: Schemas['SendEmailRequest'] = { challengeId, ...(email ? { email } : {}) }
      const { ok, status, data } = await post<{ error?: string; errorMessage?: string }>('/challenge/send-email', body)
      if (ok) return { ok: true }
      const err = kidError(status, data, { notFound: 'challengeNotFound', invalid: 'challengeResolved' })
      return { ok: false, code: err.code, error: err.message }
    },

    async challengeInviteParent(sessionId, parentEmail, playerName) {
      const body: Schemas['InviteParentRequest'] = { sessionId, parentEmail, ...(playerName ? { playerName } : {}) }
      const { ok, status, data } = await post<InviteParentResult & { error?: string; errorMessage?: string }>(
        '/challenge/invite-parent',
        body,
      )
      if (!ok) throw kidError(status, data, { notFound: 'sessionNotFound' })
      return data
    },

    async sessionChange(sessionId, name, enabled) {
      const body: Schemas['ChangeSessionRequest'] = { sessionId, name, enabled }
      const { ok, status, data } = await post<Session & { error?: string; errorMessage?: string }>(
        '/session/change',
        body,
      )
      if (ok) return { ok: true, session: data }
      const err = kidError(status, data, { notFound: 'sessionNotFound', invalid: 'permissionNotChangeable' })
      return { ok: false, code: err.code, error: err.message }
    },

    async sessionUpgrade(sessionId, permissionNames) {
      const body: Schemas['UpgradeSessionRequest'] = {
        sessionId,
        requestedPermissions: permissionNames.map((name) => ({ name })),
      }
      const { ok, status, data } = await post<SessionUpgradeResult & { error?: string; errorMessage?: string }>(
        '/session/upgrade',
        body,
      )
      if (!ok) throw kidError(status, data, { notFound: 'sessionNotFound' })
      return { session: data.session, challenge: data.challenge ?? null }
    },

    async sessionVerifyAge(sessionId) {
      const body: Schemas['VerifySessionAgeRequest'] = { sessionId }
      const { ok, status, data } = await post<
        Schemas['VerifySessionAgeResponse'] & { error?: string; errorMessage?: string }
      >('/session/verify-age', body)
      if (!ok) throw kidError(status, data, { notFound: 'sessionNotFound' })
      return { status: data.status, challenge: data.challenge ?? null }
    },

    async declare(input) {
      let iconUrl = input.iconUrl
      if (iconUrl) {
        try {
          iconUrl = await declaredIconUrl(iconUrl, doFetch)
        } catch (e) {
          throw new KidError(
            0,
            'invalid_request',
            e instanceof Error ? e.message : 'Could not read the app icon.',
            undefined,
          )
        }
      }
      const body: Schemas['DeclareRequest'] = {
        permissions: input.permissions,
        ...(input.privacyPolicyUrl !== undefined ? { privacyPolicyUrl: input.privacyPolicyUrl } : {}),
        ...(input.termsOfServiceUrl !== undefined ? { termsOfServiceUrl: input.termsOfServiceUrl } : {}),
        ...(iconUrl !== undefined ? { iconUrl } : {}),
        supportEmail: input.supportEmail,
      }
      const { ok, status, data } = await post<{ error?: string; errorMessage?: string }>('/declare', body)
      // Declare is dev-time (test mode): pass the server's specific validation detail through so the
      // integrator sees e.g. "Unknown permission: chatt" rather than a scrubbed generic string.
      if (!ok) {
        throw new KidError(
          status,
          toKidErrorCode(data.error, status),
          data.errorMessage ?? data.error ?? 'Declare failed.',
          data.error,
        )
      }
    },
  }
}
