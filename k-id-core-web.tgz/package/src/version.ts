declare const __SDK_VERSION__: string

/** Version of `@k-id/core` this bundle was built from, stamped at build time. */
export const SDK_VERSION = __SDK_VERSION__
